============
 To-Do List
============

2.0
===

* iCal filters and rights
* CalDAV rights
* CalDAV filters
