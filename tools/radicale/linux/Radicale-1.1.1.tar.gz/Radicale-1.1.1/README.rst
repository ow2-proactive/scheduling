=========
 Read Me
=========

Radicale is a free and open-source CalDAV and CardDAV server.

For complete documentation, please visit the `Radicale online documentation
<http://www.radicale.org/documentation>`_
