print("BEGIN UNet")

import json
from ast import literal_eval as make_tuple

IMG_SIZE = variables.get("IMG_SIZE")
NUM_CLASSES = int(str(variables.get("NUM_CLASSES")))
 
IMG_SIZE = make_tuple(IMG_SIZE)

if NUM_CLASSES == 2:
    NUM_CLASSES = NUM_CLASSES - 1       
else:
    NUM_CLASSES = NUM_CLASSES + 2   

    
# Define the NET model
NET_MODEL = """

class UNetEnc(nn.Module):

    def __init__(self, in_channels, features, out_channels):
        super().__init__()

        self.up = nn.Sequential(
            nn.Conv2d(in_channels, features, 3),
            nn.ReLU(inplace=True),
            nn.Conv2d(features, features, 3),
            nn.ReLU(inplace=True),
            nn.ConvTranspose2d(features, out_channels, 2, stride=2),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.up(x)


class UNetDec(nn.Module):

    def __init__(self, in_channels, out_channels, dropout=False):
        super().__init__()

        layers = [
            nn.Conv2d(in_channels, out_channels, 3),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3),
            nn.ReLU(inplace=True),
        ]
        if dropout:
            layers += [nn.Dropout(.5)]
        layers += [nn.MaxPool2d(2, stride=2, ceil_mode=True)]

        self.down = nn.Sequential(*layers)

    def forward(self, x):
        return self.down(x)


class UNet(nn.Module):

    def __init__(self, num_classes):
        super().__init__()

        self.dec1 = UNetDec(3, 64)
        self.dec2 = UNetDec(64, 128)
        self.dec3 = UNetDec(128, 256)
        self.dec4 = UNetDec(256, 512, dropout=True)
        self.center = nn.Sequential(
            nn.Conv2d(512, 1024, 3),
            nn.ReLU(inplace=True),
            nn.Conv2d(1024, 1024, 3),
            nn.ReLU(inplace=True),
            nn.Dropout(),
            nn.ConvTranspose2d(1024, 512, 2, stride=2),
            nn.ReLU(inplace=True),
        )
        self.enc4 = UNetEnc(1024, 512, 256)
        self.enc3 = UNetEnc(512, 256, 128)
        self.enc2 = UNetEnc(256, 128, 64)
        self.enc1 = nn.Sequential(
            nn.Conv2d(128, 64, 3),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, 3),
            nn.ReLU(inplace=True),
        )
        self.final = nn.Conv2d(64, num_classes, 1)

    def forward(self, x):
        dec1 = self.dec1(x)
        dec2 = self.dec2(dec1)
        dec3 = self.dec3(dec2)
        dec4 = self.dec4(dec3)
        center = self.center(dec4)
        enc4 = self.enc4(torch.cat([
            center, F.upsample_bilinear(dec4, center.size()[2:])], 1))
        enc3 = self.enc3(torch.cat([
            enc4, F.upsample_bilinear(dec3, enc4.size()[2:])], 1))
        enc2 = self.enc2(torch.cat([
            enc3, F.upsample_bilinear(dec2, enc3.size()[2:])], 1))
        enc1 = self.enc1(torch.cat([
            enc2, F.upsample_bilinear(dec1, enc2.size()[2:])], 1))

        return F.upsample_bilinear(self.final(enc1), x.size()[2:])

        
        
METHOD_NAME = 'UNet'        
Net = UNet    
assert Net is not None, f'model {MODEL_NAME} not available'
model = Net(NUM_CLASSES)
        
"""
print(NET_MODEL)

# Data augmentation and normalization for training
# Just normalization for validation and test
NET_TRANSFORM = """
import numpy as np
def colormap(n):
    cmap=np.zeros([n, 3]).astype(np.uint8)

    for i in np.arange(n):
        r, g, b = np.zeros(3)

        for j in np.arange(8):
            r = r + (1<<(7-j))*((i&(1<<(3*j))) >> (3*j))
            g = g + (1<<(7-j))*((i&(1<<(3*j+1))) >> (3*j+1))
            b = b + (1<<(7-j))*((i&(1<<(3*j+2))) >> (3*j+2))

        cmap[i,:] = np.array([r, g, b])

    return cmap

class Relabel:

    def __init__(self, olabel, nlabel):
        self.olabel = olabel
        self.nlabel = nlabel

    def __call__(self, tensor):
        assert isinstance(tensor, torch.LongTensor), 'tensor needs to be LongTensor'
        tensor[tensor == self.olabel] = self.nlabel
        return tensor


class ToLabel:

    def __call__(self, image):
        return torch.from_numpy(np.array(image)).long().unsqueeze(0)


class Colorize:

    def __init__(self, n=22):
        self.cmap = colormap(256)
        self.cmap[n] = self.cmap[-1]
        self.cmap = torch.from_numpy(self.cmap[:n])

    def __call__(self, gray_image):
        size = gray_image.size()
        color_image = torch.ByteTensor(3, size[1], size[2]).fill_(0)

        for label in range(1, len(self.cmap)):
            mask = gray_image[0] == label

            color_image[0][mask] = self.cmap[label][0]
            color_image[1][mask] = self.cmap[label][1]
            color_image[2][mask] = self.cmap[label][2]

        return color_image
        
if NUM_CLASSES == 1:
    input_transform = Compose([Resize(IMG_SIZE),ToTensor()])
    target_transform = Compose([Resize(IMG_SIZE),ToTensor()])
else:
    color_transform = Colorize()
    image_transform = ToPILImage()
    input_transform = Compose([
            Resize(IMG_SIZE),   
            ToTensor(),
            Normalize([.485, .456, .406], [.229, .224, .225]),
    ])
    target_transform = Compose([
            Resize(IMG_SIZE),     
            ToLabel(),
            Relabel(255, 21),
    ])
    
"""
print(NET_TRANSFORM)

#CRITERION FUNCTION
NET_CRITERION = """
class CrossEntropyLoss2d(nn.Module):

    def __init__(self, weight=None):
        super().__init__()

        self.loss = nn.NLLLoss(weight)

    def forward(self, outputs, targets):
        return self.loss(F.log_softmax(outputs), targets)
 
class BinaryCrossEntropyLoss2d(nn.Module):

    def __init__(self, weight=None):
        super().__init__()
        
        #self.loss = nn.BCELoss(weight)
        self.loss = nn.BCEWithLogitsLoss(weight)

    def forward(self, outputs, targets):
        #return self.loss(nn.Sigmoid(outputs), targets)
        return self.loss(outputs, targets)
        
"""
print(NET_CRITERION)

if 'variables' in locals():
  variables.put("NET_MODEL", NET_MODEL)
  variables.put("NET_TRANSFORM", NET_TRANSFORM)
  variables.put("NET_CRITERION", NET_CRITERION)
  variables.put("IMG_SIZE", IMG_SIZE)
  variables.put("NUM_CLASSES", NUM_CLASSES)

print("END UNet")